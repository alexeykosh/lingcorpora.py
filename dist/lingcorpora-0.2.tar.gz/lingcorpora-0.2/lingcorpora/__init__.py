from .ru_corpus import main as rus_search
from .pl_corpus import main as pol_search
from .ger_corpus import main as deu_search
from .zho_corpus import main as zho_search

