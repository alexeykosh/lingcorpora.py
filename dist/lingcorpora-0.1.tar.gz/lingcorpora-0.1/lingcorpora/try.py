import lingcorpora

print(lingcorpora.ger_search(query='Muther', write=True, n_results=55))